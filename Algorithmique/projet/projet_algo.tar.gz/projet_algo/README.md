Les deux itérateurs ont été implémentés dans le fichier geo/hash.py

Les fonctions reconnected() et even_degrees() ont été implémentés.

Concernant la fonction eulerian_cycle(), elle provoque un bug lors de l'exécution donc a été
commentée. De plus, le coût en temps et en mémoire de l'algorithme est trop élevée.
